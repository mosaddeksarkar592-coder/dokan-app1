# Dokan App

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/mosaddeksarkar952-coder/dokan-app&project-name=dokan-app)

Simple React + Vite + Tailwind shop dashboard.

## Run Locally

```bash
npm install
npm run dev
```

This will start the local dev server at http://localhost:5173
